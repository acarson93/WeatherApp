package com.example.ac.weathera;

/**
 * Created by AC on 1/24/2017.
 */
public class Clouds {

    private int precipitation;

    public int getPrecipitation() {
        return precipitation;
    }

    public void setPrecipitation(int precipitation) {
        this.precipitation = precipitation;
    }
}
