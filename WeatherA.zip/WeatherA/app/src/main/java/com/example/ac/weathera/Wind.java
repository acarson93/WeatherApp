package com.example.ac.weathera;

/**
 * Created by AC on 1/24/2017.
 */
public class Wind {

    private float velocity;
    private float degree;

    public float getVelocity() {
        return velocity;
    }

    public void setVelocity(float velocity) {
        this.velocity = velocity;
    }

    public float getDegree() {
        return degree;
    }

    public void setDegree(float degree) {
        this.degree = degree;
    }
}
