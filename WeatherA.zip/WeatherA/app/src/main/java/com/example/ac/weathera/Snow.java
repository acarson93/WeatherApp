package com.example.ac.weathera;

/**
 * Created by AC on 1/24/2017.
 */
public class Snow {


    private int precip;

    public int getPrecip() {
        return precip;
    }

    public void setPrecip(int precip) {
        this.precip = precip;
    }
}
